package com.sparkspeedfix

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(18, 59, 114)
        window.navigationBarColor = android.graphics.Color.rgb(18, 59, 114)

        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(android.graphics.Color.rgb(245, 248, 252))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "⚡ Spark Speed Fix"
            textSize = 26f
            setTextColor(android.graphics.Color.rgb(18, 59, 114))
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title)
        addText("Made for Android phones including TECNO Spark Go BG6m. This app checks basic device health and opens safe system settings; it does not use fake RAM-boosting tricks.")
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(android.graphics.Color.rgb(35, 45, 58))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        root.addView(status, marginParams())
        addButton("Run phone health check", ::refreshHealth)
        addButton("Open storage settings", { openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) })
        addButton("Open app list (uninstall / clear cache)", { openSettings(Settings.ACTION_APPLICATION_SETTINGS) })
        addButton("Open battery settings", { openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS) })
        addButton("Open display settings", { openSettings(Settings.ACTION_DISPLAY_SETTINGS) })
        addButton("Open developer options (animations)", {
            openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        })
        addButton("Open system settings", { openSettings(Settings.ACTION_SETTINGS) })
        addText("Safe tips:\n• Keep at least 1–2 GB storage free where possible.\n• Uninstall apps you do not use and remove downloaded files you recognize.\n• In app settings, clear cache (not storage/data) for apps that misbehave.\n• Restart the phone after installing updates.\n• If enabled in Developer options, set Window, Transition and Animator scales to 0.5× for snappier animations.\n• Do not disable system apps or install unknown “RAM booster” apps.")
        addText("Limitations: Android does not let an ordinary app forcibly clean other apps' RAM or clear their private data. If freezing continues, the cause may be a buggy app, overheating, storage wear, or a system issue.")
        refreshHealth()
    }

    private fun refreshHealth() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val memAvail = mi.availMem / (1024L * 1024L)
        val memTotal = if (Build.VERSION.SDK_INT >= 16) mi.totalMem / (1024L * 1024L) else -1L

        val stat = StatFs(Environment.getDataDirectory().absolutePath)
        val block = stat.blockSizeLong
        val free = stat.availableBlocksLong * block / (1024L * 1024L)
        val total = stat.blockCountLong * block / (1024L * 1024L)
        val usedPct = if (total > 0) ((total - free) * 100 / total).toInt() else 0

        status.text = "PHONE HEALTH CHECK\n\n" +
            "Android version: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Available RAM: ${memAvail} MB" +
            (if (memTotal > 0) " of ${memTotal} MB" else "") + "\n" +
            "Free internal storage: ${free} MB of ${total} MB\n" +
            "Storage used: ${usedPct}%\n\n" +
            (if (free < 1024) "Suggestion: storage is low. Remove files or apps you recognize." else
                "Storage: there is at least about 1 GB free. Check background apps and updates if lag continues.") +
            "\n\nNote: available RAM changes constantly; this is a snapshot, not a speed score."
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun addText(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(android.graphics.Color.rgb(65, 76, 90))
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(tv, marginParams())
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setOnClickListener { action() }
        }
        root.addView(button, marginParams())
    }

    private fun marginParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(10)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
