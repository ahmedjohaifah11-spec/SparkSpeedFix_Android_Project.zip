# Spark Speed Fix — Android project

A small, offline Android utility for basic device health checks and shortcuts to Android settings. Designed to work on Android 6.0+ devices, including the TECNO Spark Go BG6m.

## What it does
- Shows Android version, currently available RAM, internal storage free/total, and storage usage.
- Opens Android's storage, app management, battery, display, developer-options, and general settings.
- Gives practical, safe troubleshooting tips.

## Important limitations
This app does **not** promise to speed up hardware or forcibly close other apps. Normal Android apps cannot safely clear other apps' private data or arbitrarily free RAM. It does not collect data or require internet access.

## Build an installable APK
This project source is provided because the current build environment does not have the Android SDK/Gradle build tools needed to compile and verify an APK.

On a computer:
1. Install the latest stable Android Studio from the official Android developer website.
2. Open Android Studio and choose **Open**, then select this `SparkSpeedFix` folder.
3. Allow Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build finishes, choose **locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your TECNO phone. Open it from Files and allow **Install unknown apps** for the app you used to open it, if Android asks. Install only the APK you built from this project.

## Recommended phone settings
- Keep storage comfortably free.
- Use Settings > Apps to uninstall unused apps and clear cache for apps that freeze.
- Set animation scales to 0.5x in Developer options if available.
- Avoid third-party RAM cleaners; they often cause more background restarting.


## Optional: build online with GitHub Actions
The ZIP includes a workflow at `.github/workflows/build-apk.yml`.
1. Create/sign in to GitHub and create a new repository.
2. Upload the extracted project files (including the hidden `.github` folder) to the repository.
3. Open the repository's **Actions** tab and run **Build Spark Speed Fix APK** (or push to the `main` branch).
4. Open the completed workflow run and download the **SparkSpeedFix-debug-apk** artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then transfer it to your phone.
